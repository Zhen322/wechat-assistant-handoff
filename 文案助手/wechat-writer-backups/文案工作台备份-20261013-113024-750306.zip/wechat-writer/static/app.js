'use strict';

const $ = (s, root = document) => root.querySelector(s);
const $$ = (s, root = document) => [...root.querySelectorAll(s)];
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icon = name => `<svg class="icon" aria-hidden="true"><use href="#i-${name}"/></svg>`;
const safeURL = raw => {try { const u = new URL(raw); return ['http:', 'https:'].includes(u.protocol) ? u.href : ''; } catch {return '';}};
const fmtDate = value => {if (!value) return '未记录'; const d = new Date(value); return Number.isNaN(+d) ? String(value) : d.toLocaleDateString('zh-CN', {year:'numeric',month:'2-digit',day:'2-digit'});};
const chars = value => [...(value || '').replace(/\s/g, '')].length;
const labels = {home:'写作工作台',articles:'素材库',cards:'写法卡片',notes:'我的思考',drafts:'文章草稿',settings:'模型与设置'};
let state = {articles:[],cards:[],drafts:[],notes:{text:'',path:'',revision:''},settings:{},jobs:[],stats:{}};
let page = 'home', modal = null, modalDirty = false, settingsDirty = false;
let noteSession = null, noteConflict = null, notesPollBusy = false, jobsBusy = false;
let articleFilter = {query:'',heat:'all',sort:'newest'};
let composer = {brief:'',audience:'整灯厂和上游供应商从业者',tone:'专业、有观点，兼顾行业深度与可读性',length:'1500—2000 字',article_ids:[],use_web:false};
let trackedJobs = new Map();
let activeDraft = null, draftPreview = false;

async function api(path, options = {}) {
  const response = await fetch(path, {headers:{'Content-Type':'application/json'},...options,body:options.body === undefined ? undefined : JSON.stringify(options.body)});
  let data;
  try {data = await response.json();} catch {throw new Error(`服务响应异常（${response.status}），请确认本地服务正在运行。`);}
  if (!response.ok) {const e = new Error(data.error || `请求失败（${response.status}）`); e.status = response.status; throw e;}
  return data;
}
function toast(message, error = false) {
  const el = document.createElement('div'); el.className = `toast${error ? ' error' : ''}`; el.textContent = message;
  $('#toast-root').append(el); setTimeout(() => el.remove(), error ? 9000 : 4800);
}
function formError(form, message) {
  let el = $('.form-error', form); if (!el) {el = document.createElement('div');el.className='form-error';el.setAttribute('role','alert');form.append(el);} el.textContent = message;
}
async function busy(button, work) {
  if (button?.disabled) return;
  const old = button?.innerHTML; if (button) {button.disabled=true;button.innerHTML='<span class="spinner"></span> 处理中…';}
  try {return await work();} finally {if (button?.isConnected) {button.disabled=false;button.innerHTML=old;}}
}
function modelLabel(settings=state.settings){return `${({ollama:'本地模型',codex:'Codex 会员',openai:'云端 API'})[settings.provider]||'写作模型'} · ${settings.model||'待配置'}`;}
function modelPrivacy(provider){
  if(provider==='codex')return '使用本机 Codex 登录，无需另填 API 密钥，消耗同一账号 Codex 额度。本次选用的素材、写法卡片和笔记会发送至 OpenAI；模型可用性取决于账号。';
  if(provider==='ollama')return '当前使用本地模型。联网搜索仍会把搜索词发送至搜索服务。';
  return '使用云端模型时，本次选用的素材、写法卡片及个人笔记会发送至你配置的模型服务。';
}
function updateProviderFields(selectDefaults=false){
  const provider=$('#provider').value, codex=provider==='codex',local=provider==='ollama';
  $('#base-url-field').hidden=codex;$('#base_url').disabled=codex;$('#base_url').required=!codex;
  $('#api-key-field').hidden=codex;$('#api_key').disabled=codex;
  $('#model').placeholder=codex?'gpt-6-astra':local?'qwen2.5:latest':'填写服务商提供的模型名称';
  if(selectDefaults){
    if(codex)$('#model').value=state.settings.provider==='codex'&&state.settings.model?state.settings.model:'gpt-6-astra';
    else if(local)$('#model').value=state.settings.provider==='ollama'&&state.settings.model?state.settings.model:'qwen2.5:latest';
    else $('#model').value=state.settings.provider==='openai'?state.settings.model||'':'';
    if(!codex&&['http://localhost:11434','http://127.0.0.1:11434','https://api.openai.com/v1',''].includes($('#base_url').value))$('#base_url').value=local?'http://localhost:11434':'https://api.openai.com/v1';
  }
  $('#model-privacy').textContent=modelPrivacy(provider);
  $('#model-preset-help').textContent=codex?'GPT-6 Astra 使用本机已登录的 Codex 账号；保存后可测试模型。':'点击预设可切换到 Codex 会员并使用 GPT-6 Astra。';
}
function updateChrome() {
  for (const name of ['articles','cards','drafts']) $(`#nav-${name}`).textContent=state[name].length;
  $('#model-status').textContent=modelLabel();
  $('#page-label').textContent=labels[page];
  $$('[data-page]').forEach(b => b.classList.toggle('active',b.dataset.page===page));
}
async function reloadState(render = true) {
  state = await api('/api/state');
  ['articles','cards','drafts','jobs'].forEach(k => {if(!Array.isArray(state[k])) state[k]=[];});
  updateChrome();
  if (render && !settingsDirty && !(page==='notes' && noteSession)) renderPage();
}
function pageHeading(kicker,title,description,actions='') {return `<div class="page-heading"><div><div class="page-kicker">${kicker}</div><h1>${title}</h1><p>${description}</p></div>${actions ? `<div class="header-actions">${actions}</div>` : ''}</div>`;}
function emptyState(name,title,description,button='') {return `<div class="empty-state"><div class="empty-icon">${icon(name)}</div><h3>${title}</h3><p>${description}</p>${button}</div>`;}
function hasUnsaved() {return settingsDirty || (page==='notes' && noteSession?.dirty);}
async function navigate(next) {
  if (!labels[next]) next='home';
  if (next!==page && hasUnsaved() && !confirm('当前页面有尚未保存的修改。离开会放弃这些修改，确定继续吗？')) return;
  if (next!==page) {settingsDirty=false;if(page==='notes'){noteSession=null;noteConflict=null;}}
  page=next;history.replaceState(null,'',`#${page}`);updateChrome();renderPage();window.scrollTo(0,0);
  if (page==='notes') await pollNotes();
}
function renderPage() {
  const renderers={home:renderHome,articles:renderArticles,cards:renderCards,notes:renderNotes,drafts:renderDrafts,settings:renderSettings};
  $('#main').innerHTML=renderers[page]();
  if(page==='notes') updateNoteIndicators();
}

function renderHome() {
  const approved=state.cards.filter(c=>c.approved), noteCount=chars(state.notes.text);
  return `<section class="hero"><div><div class="eyebrow">INDUSTRY CONTENT STUDIO</div><h1>让行业经验，<br>长成<span style="color:#769367">值得读的文章。</span></h1><p>从一条行业线索，到一篇有你观点的公众号文章。</p></div><div class="hero-badge">${icon('spark')} 汽车与车灯产业 · 专属写作空间</div></section>
  <div class="workflow" aria-label="工作流程"><span class="workflow-item"><span class="workflow-number">01</span> 收集好文章</span><span class="workflow-arrow"></span><span class="workflow-item"><span class="workflow-number">02</span> 拆解好写法</span><span class="workflow-arrow"></span><span class="workflow-item"><span class="workflow-number">03</span> 加入你的思考</span><span class="workflow-arrow"></span><span class="workflow-item active"><span class="workflow-number">04</span> 写一篇新文章</span></div>
  <div class="home-grid"><section class="panel"><div class="panel-header"><div class="panel-heading">${icon('note')}<h2>今天，想写点什么？</h2></div><small>NEW DRAFT</small></div>
  <form id="compose-form" class="composer-body"><label class="form-label" for="brief">文章主题与写作要求</label><textarea id="brief" name="brief" class="topic-input" required placeholder="例如：ADB 车灯越来越普及，整灯厂和光学供应商的竞争，正在发生哪些变化？\n\n写下你的观点、想讨论的问题，或希望读者带走的结论。">${esc(composer.brief)}</textarea>
  <div class="suggestions"><button class="suggestion" type="button" data-topic="围绕 ADB 车灯普及，分析整灯厂与光学供应商的机会、挑战与协同方式。区分已验证事实与趋势判断。">ADB 与智能车灯</button><button class="suggestion" type="button" data-topic="从汽车车灯产业链视角，讨论降本压力下，整灯厂和上游供应商如何在成本、质量和技术差异化之间取舍。">供应链与降本</button><button class="suggestion" type="button" data-topic="面向车灯产业链从业者，讨论新材料与光学设计如何影响车灯性能、可靠性与量产。明确技术边界，避免营销夸大。">材料与光学创新</button></div>
  <div class="field"><label class="form-label" for="audience">写给谁看</label><input id="audience" name="audience" value="${esc(composer.audience)}" required></div>
  <div class="form-row"><div><label class="form-label" for="tone">文章语气</label><select id="tone" name="tone">${['专业、有观点，兼顾行业深度与可读性','深入浅出，用具体问题讲清技术','克制客观，适合产业观察','鲜明有力，适合观点评论'].map(x=>`<option${composer.tone===x?' selected':''}>${x}</option>`).join('')}</select></div><div><label class="form-label" for="length">建议篇幅</label><select id="length" name="length">${['800—1200 字','1500—2000 字','2500—3000 字'].map(x=>`<option${composer.length===x?' selected':''}>${x}</option>`).join('')}</select></div></div>
  <div class="reference-box"><div class="reference-head"><label class="form-label" style="margin:0">参考素材 <small>按需选择</small></label><button type="button" class="text-button" data-page="articles">去素材库 ${icon('arrow')}</button></div>
  ${state.articles.length?`<div class="reference-list">${state.articles.map(a=>`<label class="check-row"><input type="checkbox" name="article_ids" value="${esc(a.id)}"${composer.article_ids.includes(String(a.id))?' checked':''}><span>${esc(a.title)}${a.content_kind==='snippet'?' <span class="tag orange">仅搜索摘要</span>':''}</span></label>`).join('')}</div>`:`<div class="reference-empty">${icon('book')} 添加第一篇文章，让写作有据可依。</div>`}
  <div class="reference-note">${icon('check')} 每次读取最新笔记 · 参考 ${Math.min(approved.length,12)} 张已启用卡片${approved.length>12?'（按添加时间取最近 12 张）':''}</div><div class="help" style="font-size:9px">最多选择 8 篇素材；开启联网时最多选择 5 篇。</div></div>
  <div class="composer-bottom"><label class="toggle-row"><span class="toggle"><input type="checkbox" name="use_web"${composer.use_web?' checked':''}><span></span></span><span class="toggle-text">联网补充资料</span></label><span class="toggle-caption">${state.settings.tavily_configured?'Tavily 已配置':'免密试用 · 有额度限制'}</span></div>
  <button class="button primary full" type="submit">${icon('spark')} 开始写作 ${icon('arrow')}</button><p class="fine-print">${state.settings.provider==='codex'?`${esc(modelLabel())}<br>${esc(modelPrivacy('codex'))}`:state.settings.provider==='ollama'?'使用本机模型生成，耗时取决于文章长度与电脑性能':'使用你配置的云端 API 生成，所选资料将发送至该服务'}</p></form></section>
  <aside class="desk-column"><div class="panel desk-panel"><div class="panel-header"><div><h2 style="font-size:14px">你的写作底座</h2><span class="small-kicker">COLLECT. THINK. CREATE.</span></div>${icon('folder')}</div><div class="foundation">${foundationRow('book','行业素材','值得参考的文章与资料',state.articles.length,'articles')}${foundationRow('cards','可用写法','经过你审核的表达与结构',approved.length,'cards')}${foundationRow('file','文章草稿','每一次积累，都留下来',state.drafts.length,'drafts')}</div></div>
  <div class="notebook-teaser"><span class="corner-mark">”</span><div class="panel-heading">${icon('note')}<h2>你的思考，始终在场</h2></div><p>把观察、判断和一闪而过的灵感，记在同一份 Markdown 笔记里。每次写作，都会重新读取。</p><button class="text-button" data-page="notes">打开我的思考 ${icon('arrow')}</button><div class="help" style="font-size:8px;margin-top:9px">本地文件 · ${noteCount.toLocaleString()} 字 · 保存后同步</div></div>
  <div class="principle"><div class="principle-title">${icon('check')} 参考好文章，写出自己的判断</div><p>提炼标题、开头与结构方法。公开热度逐项记录来源，未公开的数据保持未知。</p></div></aside></div>`;
}
function foundationRow(i,title,desc,count,next){return `<div class="foundation-row"><span class="foundation-icon">${icon(i)}</span><div class="foundation-main"><strong>${title}</strong><small>${desc}</small></div><b>${count}</b><button data-page="${next}" aria-label="打开${title}">${icon('arrow')}</button></div>`;}

function metricNumber(value) {
  if(value===null||value===undefined||String(value).trim()==='')return null;
  const s=String(value).trim().replace(/,/g,'').replace(/＋/g,'+');
  const m=s.match(/^(\d+(?:\.\d+)?)\s*(亿|万|[kKmM])?\+?$/);if(!m)return null;
  const factor={'亿':1e8,'万':1e4,k:1e3,K:1e3,m:1e6,M:1e6};return Number(m[1])*(factor[m[2]]||1);
}
function hasMetrics(a){return ['reads','likes','favorites'].some(k=>metricNumber(a.metrics?.[k])!==null);}
function visibleArticles() {
  let list=state.articles.filter(a=>(`${a.title} ${a.content} ${(a.tags||[]).join(' ')}`).toLowerCase().includes(articleFilter.query.toLowerCase()));
  if(articleFilter.heat==='known') list=list.filter(hasMetrics);
  if(articleFilter.heat==='unknown') list=list.filter(a=>!hasMetrics(a));
  return list.sort((a,b)=>{if(articleFilter.sort==='newest')return new Date(b.created_at)-new Date(a.created_at);const x=metricNumber(a.metrics?.[articleFilter.sort]),y=metricNumber(b.metrics?.[articleFilter.sort]);if(x===null&&y===null)return 0;if(x===null)return 1;if(y===null)return -1;return y-x;});
}
function renderArticles() {
  return `${pageHeading('SOURCE LIBRARY','把好内容，变成自己的积累。','收集行业文章、补充真实热度，再拆解值得复用的写法。',`<button class="button secondary" data-action="research">${icon('search')} 搜索产业文章</button><button class="button primary" data-action="add-article">${icon('plus')} 添加素材</button>`)}
  <div class="search-banner">${icon('globe')}<div><h3>寻找有价值的产业文章，从真实来源开始</h3><p>搜索结果按相关性返回；阅读、点赞与收藏需以原文或你的记录核验。</p></div><button class="button secondary small" data-action="research">去搜索 ${icon('arrow')}</button></div>
  <div class="article-toolbar"><div class="search-input-wrap">${icon('search')}<input id="library-filter" placeholder="搜索已收藏的文章…" value="${esc(articleFilter.query)}" aria-label="搜索素材库"></div><select id="heat-filter" aria-label="热度筛选"><option value="all"${articleFilter.heat==='all'?' selected':''}>全部热度</option><option value="known"${articleFilter.heat==='known'?' selected':''}>有热度记录</option><option value="unknown"${articleFilter.heat==='unknown'?' selected':''}>热度待核验</option></select><select id="article-sort" aria-label="素材排序"><option value="newest"${articleFilter.sort==='newest'?' selected':''}>最近收藏</option><option value="reads"${articleFilter.sort==='reads'?' selected':''}>阅读从高到低</option><option value="likes"${articleFilter.sort==='likes'?' selected':''}>点赞从高到低</option><option value="favorites"${articleFilter.sort==='favorites'?' selected':''}>收藏从高到低</option></select></div><div id="article-results">${articleResults()}</div>`;
}
function articleResults(){const list=visibleArticles();return list.length?`<div class="article-grid">${list.map(articleCard).join('')}</div>`:emptyState('book',state.articles.length?'还没有符合条件的素材':'你的第一篇好文章，值得留下来。',state.articles.length?'试试其他关键词，或切换热度筛选。':'粘贴文章正文、上传文件，或搜索汽车与车灯产业资料。从这里开始建立你的内容资料库。',state.articles.length?'':`<button class="button secondary" data-action="add-article">${icon('plus')} 添加第一篇素材</button>`);}
function metricLabel(v){return v!==undefined&&v!==null&&String(v).trim()!=='' ? esc(v) : '未知';}
function articleCard(a){return `<article class="article-card"><div class="article-card-top"><span class="tag">${{manual:'手动收藏',upload:'文件导入',web:'网络来源'}[a.source_type]||'我的素材'}</span>${a.content_kind==='snippet'?'<span class="tag orange">仅搜索摘要</span>':''}${a.analysis?'<span class="tag">已拆解</span>':''}${!hasMetrics(a)?'<span class="tag gray">热度待核验</span>':''}</div><button class="article-title" data-article="${esc(a.id)}">${esc(a.title)}</button><p class="article-excerpt">${esc(a.content)}</p><div class="article-metrics"><span>阅读 <b>${metricLabel(a.metrics?.reads)}</b></span><span>点赞 <b>${metricLabel(a.metrics?.likes)}</b></span><span>收藏 <b>${metricLabel(a.metrics?.favorites)}</b></span></div><div class="article-card-bottom"><small>${esc(a.author||'作者未记录')} · 收藏于 ${esc(fmtDate(a.created_at))}</small><button class="text-button" data-article="${esc(a.id)}">查看素材 ${icon('arrow')}</button></div></article>`;}

function renderCards(){const approved=state.cards.filter(c=>c.approved).length;return `${pageHeading('WRITING METHODS','好写法，值得反复用。',`把文章拆解为可复用的方法。审核后启用，写作时自动参考。当前已启用 ${approved} 张。`)}<p class="subtle-note">卡片来自实际文章拆解：标题逻辑、开头方法、叙事结构与表达技巧。它们提供写法，不授权复制原文或挪用作者经历。</p>${state.cards.length?`<div class="cards-grid">${state.cards.map(c=>`<article class="article-card method-card"><div class="card-head"><span class="tag">${esc(c.category||'写作方法')}</span><span class="tag ${c.approved?'':'orange'}">${c.approved?'已启用':'待你审核'}</span></div><h3>${esc(c.title)}</h3><p>${esc(c.content)}</p><div class="method-source">来源：${esc(c.source_title||'已收藏文章')}</div><div class="method-approval"><button class="text-button" data-edit-card="${esc(c.id)}">编辑方法</button><button class="button ${c.approved?'secondary':'primary'} small" data-approve-card="${esc(c.id)}" data-approved="${!c.approved}">${icon(c.approved?'close':'check')} ${c.approved?'停用卡片':'审核并启用'}</button></div></article>`).join('')}</div>`:emptyState('cards','还没有写法卡片','添加一篇完整文章，点击「拆解文章」。AI 会提炼标题、开头和结构方法，等待你审核后再用于写作。',`<button class="button secondary" data-page="articles">去素材库 ${icon('arrow')}</button>`)}`;}

function renderNotes(){if(!noteSession)noteSession={text:state.notes.text||'',revision:state.notes.revision,path:state.notes.path,dirty:false};return `${pageHeading('YOUR OWN VOICE','好文章里，应该有你的思考。','一份可以持续编辑的本地 Markdown 笔记。你的观察与判断，是写作最重要的参考。')}<section class="panel"><div class="notes-toolbar"><div><div class="notes-file">${icon('file')} 我的思考.md</div><p class="notes-path">${esc(noteSession.path)}</p></div><div class="header-actions"><button class="button secondary small" data-action="open-notes">${icon('folder')} 用本地编辑器打开</button><button class="button primary small" data-action="save-notes">${icon('check')} 保存笔记</button></div></div><div id="note-conflict"${noteConflict?'':' hidden'}></div><label class="visually-hidden" for="notes-editor">我的思考 Markdown 编辑区</label><textarea id="notes-editor" class="editor" spellcheck="false">${esc(noteSession.text)}</textarea><div class="editor-footer"><span id="note-status" class="save-indicator">已同步到本地文件</span><span id="note-count" class="word-count">${chars(noteSession.text)} 字</span></div></section><div class="notes-help">${icon('clock')}<span>保存后供下次写作读取。用 Typora、Obsidian 等编辑同一个文件时，这里每 5 秒检查变化；遇到同时编辑会提示合并，不会直接覆盖。可在「模型与设置」选择你已有的 .md 笔记。</span></div>`;}
function updateNoteIndicators(){if(!noteSession||page!=='notes')return;const status=$('#note-status');if(status){status.textContent=noteSession.dirty?'有未保存的修改':'已同步到本地文件';status.classList.toggle('dirty',noteSession.dirty);}if($('#note-count'))$('#note-count').textContent=`${chars(noteSession.text).toLocaleString()} 字`;const conflict=$('#note-conflict');if(conflict){conflict.hidden=!noteConflict;if(noteConflict){conflict.className='conflict-banner';conflict.innerHTML=`本地文件已被另一编辑器修改。请对照磁盘版本合并，或加载它；当前输入仍保留在编辑区。<details><summary>查看磁盘新版本</summary><pre style="white-space:pre-wrap;max-height:180px;overflow:auto">${esc(noteConflict.text)}</pre></details><button class="button secondary small" data-action="reload-notes">加载磁盘版本</button><button class="button secondary small" data-action="merge-notes">我已合并，保存当前内容</button>`;}}}
async function pollNotes(){if(notesPollBusy)return;notesPollBusy=true;try{const latest=await api('/api/notes');state.notes=latest;if(page==='notes'&&noteSession&&latest.revision!==noteSession.revision){if(noteSession.dirty){noteConflict=latest;}else{noteSession={...latest,dirty:false};const ed=$('#notes-editor');if(ed)ed.value=latest.text;noteConflict=null;}updateNoteIndicators();}}catch(e){if(page==='notes'&&$('#note-status')){$('#note-status').textContent=`同步失败：${e.message}`;$('#note-status').classList.add('dirty');}}finally{notesPollBusy=false;}}
async function saveNotes(button, merged=false){if(!noteSession)return;const editingSession=noteSession;const submittedText=noteSession.text;await busy(button,async()=>{try{const revision=merged&&noteConflict?noteConflict.revision:editingSession.revision;const result=await api('/api/notes',{method:'PUT',body:{text:submittedText,revision}});state.notes=result;if(noteSession===editingSession){noteSession.revision=result.revision;noteSession.path=result.path;noteSession.dirty=noteSession.text!==submittedText;noteConflict=null;updateNoteIndicators();toast(noteSession.dirty?'已保存提交时的笔记，之后新增的编辑仍待保存。':'笔记已保存，下次写作将读取最新内容。');}else toast('笔记已保存。');}catch(e){if(e.status===409){await pollNotes();toast('文件已在其他编辑器中更新，请先合并两份修改。',true);}else toast(e.message,true);}});}

function renderDrafts(){return `${pageHeading('DRAFTS & IDEAS','每一篇草稿，都是新的起点。','修改文字、核对来源，再把 Markdown 草稿带到公众号编辑器。',`<button class="button primary" data-page="home">${icon('plus')} 写新文章</button>`)}${state.drafts.length?`<div class="draft-list">${state.drafts.map(d=>`<article class="draft-row">${icon('file')}<div><h3>${esc(d.title)}</h3><small>${esc(fmtDate(d.created_at))} · ${chars(d.content).toLocaleString()} 字 · ${esc(d.model||'模型未记录')}</small></div><button class="button secondary small" data-draft="${esc(d.id)}">打开草稿 ${icon('arrow')}</button></article>`).join('')}</div>`:emptyState('file','你的下一篇文章，从这里开始。','从工作台输入主题，选择参考素材，再让你的积累和观点进入文章。生成的草稿会自动保存在这里。',`<button class="button secondary" data-page="home">开始写作 ${icon('arrow')}</button>`)}`;}
function renderSettings(){const s=state.settings;return `${pageHeading('SETTINGS','把工具，调成顺手的样子。','选择模型、连接网络搜索，并指定你每天打开的那一份笔记。')}<form id="settings-form"><div class="settings-grid"><section class="panel settings-panel"><h2>写作模型</h2><p class="help">使用本机 Codex 会员账号调用 GPT-6 Astra，也可选择 Ollama 本地模型或兼容 OpenAI 的 API。</p><div class="field"><label class="form-label" for="provider">模型来源</label><select id="provider" name="provider"><option value="codex"${s.provider==='codex'?' selected':''}>Codex 会员 · 使用本机登录</option><option value="ollama"${s.provider==='ollama'?' selected':''}>Ollama · 本地模型</option><option value="openai"${s.provider==='openai'?' selected':''}>OpenAI 兼容 API · 云端模型</option></select></div><div class="field" id="base-url-field"${s.provider==='codex'?' hidden':''}><label class="form-label" for="base_url">服务地址</label><input id="base_url" name="base_url" value="${esc(s.base_url||'http://127.0.0.1:11434')}" placeholder="http://localhost:11434"${s.provider==='codex'?' disabled':' required'}></div><div class="field"><label class="form-label" for="model">模型名称</label><input id="model" name="model" value="${esc(s.model)}" required placeholder="${s.provider==='codex'?'gpt-6-astra':s.provider==='ollama'?'qwen2.5:latest':'填写服务商提供的模型名称'}"><div style="margin-top:10px"><button type="button" class="button subtle small" data-action="use-codex-gpt6">${icon('spark')} GPT-6 Astra · Codex 会员</button></div><p class="help" id="model-preset-help">${s.provider==='codex'?'GPT-6 Astra 使用本机已登录的 Codex 账号；保存后可测试模型。':'点击预设可切换到 Codex 会员并使用 GPT-6 Astra。'}</p></div><div class="field" id="api-key-field"${s.provider==='codex'?' hidden':''}><label class="form-label" for="api_key">API 密钥 <small>${s.api_key_configured?'已保存；留空保持不变':'本地 Ollama 无需填写'}</small></label><input id="api_key" name="api_key" type="password" autocomplete="new-password"${s.provider==='codex'?' disabled':''} placeholder="${s.api_key_configured?'••••••••（已配置）':'仅使用云端服务时填写'}"></div><div class="inline-notice" id="model-privacy">${esc(modelPrivacy(s.provider))}</div><div class="settings-footer"><button class="button primary" type="submit">${icon('check')} 保存设置</button><button type="button" class="button secondary" data-action="test-model">测试已保存的模型</button></div></section><div style="display:flex;flex-direction:column;gap:20px"><section class="panel settings-panel"><h2>联网搜索</h2><p class="help">通过 Tavily 搜索真实网页。微信文章可能受访问限制，可粘贴原文补充完整内容。</p><div class="field"><label class="form-label" for="tavily_api_key">Tavily API 密钥 <small>可选</small></label><input id="tavily_api_key" name="tavily_api_key" type="password" autocomplete="new-password" placeholder="${s.tavily_configured?'••••••••（已配置，留空保持）':'留空可免密试用，额度有限'}"><p class="help">${s.tavily_configured?'已配置个人密钥，留空保留现有配置。':'未配置个人密钥 · 免密试用有额度限制。额度不足时请填入自己的密钥。'}</p></div></section><section class="panel settings-panel"><h2>你的长期笔记</h2><p class="help">默认使用工作台的数据文件。也可填写已有 Markdown 文件的绝对路径，连接你正在用的笔记。</p><div class="field"><label class="form-label" for="notes_path">Markdown 文件路径</label><input id="notes_path" name="notes_path" value="${esc(s.notes_path||'')}" placeholder="留空使用默认的「我的思考.md」"><p class="help">当前文件：${esc(state.notes.path)}<br>选择已有文件只切换读取位置，不覆盖文件内容。</p></div></section><section class="panel settings-panel"><h2>公众号定位</h2><p class="help">每次写作都会参考这段长期定位。</p><label class="visually-hidden" for="profile">公众号定位</label><textarea id="profile" name="profile" rows="5">${esc(s.profile||'为汽车与车灯上下游公众号，面向整灯厂和上游供应商从业者。专业、具体、有判断，重视技术边界与产业价值。')}</textarea></section></div></div><div id="settings-error"></div></form>`;}

function showModal(title,body,{wide=false,tabs='',type='generic',id=null}={}){
  modal={type,id};modalDirty=false;$('#modal-root').innerHTML=`<div class="modal-backdrop"><section class="modal ${wide?'wide':''}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><header class="modal-header"><h2>${esc(title)}</h2><button class="icon-button" data-action="close-modal" aria-label="关闭">${icon('close')}</button></header>${tabs}<div class="modal-body">${body}</div></section></div>`;document.body.style.overflow='hidden';setTimeout(()=>$('.modal input,.modal textarea,.modal button')?.focus(),30);
}
function closeModal(force=false){if(!force&&modalDirty&&!confirm('有尚未保存的修改。确定关闭并放弃吗？'))return false;$('#modal-root').innerHTML='';document.body.style.overflow='';modal=null;modalDirty=false;activeDraft=null;return true;}
function addArticle(tab='paste'){
  if(modalDirty&&!confirm('切换添加方式会清空尚未保存的输入，是否继续？'))return;
  const tabs=`<div class="modal-tabs"><button class="modal-tab ${tab==='paste'?'active':''}" data-add-tab="paste">粘贴文章</button><button class="modal-tab ${tab==='url'?'active':''}" data-add-tab="url">从链接导入</button><button class="modal-tab ${tab==='upload'?'active':''}" data-add-tab="upload">上传文件</button></div>`;
  let body='';
  if(tab==='paste')body=`<form id="add-article-form"><div class="field"><label class="form-label" for="article-title">文章标题</label><input id="article-title" name="title" required placeholder="值得留下来的那篇文章"></div><div class="field"><label class="form-label" for="article-content">文章正文</label><textarea id="article-content" name="content" rows="9" required placeholder="粘贴完整正文。阅读量、点赞量等可在下方手动记录。"></textarea></div><div class="form-row"><div class="field"><label class="form-label">原文链接 <small>选填</small></label><input name="url" type="url" placeholder="https://…"></div><div class="field"><label class="form-label">作者 / 公众号 <small>选填</small></label><input name="author" placeholder="记录真实出处"></div></div><details><summary class="form-label" style="cursor:pointer">补充热度数据与来源（选填）</summary>${metricsFields()}</details><div class="modal-actions"><button class="button primary" type="submit">${icon('plus')} 收藏到素材库</button></div></form>`;
  if(tab==='url')body=`<form id="import-form"><div class="field"><label class="form-label" for="import-url">文章链接</label><input id="import-url" name="url" type="url" required placeholder="https://mp.weixin.qq.com/s/…"></div><p class="help">只导入能够公开访问的正文。微信页面若需要登录、验证或无法提取，请改用「粘贴文章」保存完整内容。</p><div class="modal-actions"><button class="button primary" type="submit">${icon('link')} 读取并收藏</button></div></form>`;
  if(tab==='upload')body=`<form id="upload-form"><label class="upload-zone">${icon('upload')}<strong>把好文章带进素材库</strong><small>支持 .md、.txt、.html、.docx；PDF 取决于本机组件</small><input name="file" type="file" accept=".md,.txt,.html,.htm,.docx,.pdf" required></label><p class="help">文件会提取为可编辑正文。图片或扫描 PDF 可能无法提取，请优先使用文本文件。</p><div class="modal-actions"><button class="button primary" type="submit">${icon('upload')} 上传并收藏</button></div></form>`;
  showModal('添加一份值得参考的素材',body,{tabs,type:'add'});
}
function metricsFields(m={}){return `<div style="margin-top:13px"><div class="metric-fields"><label>阅读<input name="reads" value="${esc(m.reads||'')}" placeholder="未知，例如 10万+"></label><label>点赞<input name="likes" value="${esc(m.likes||'')}" placeholder="未知，例如 1200"></label><label>收藏<input name="favorites" value="${esc(m.favorites||'')}" placeholder="未知"></label></div><div class="form-row"><div><label class="form-label">数据来源</label><input name="metric_source" value="${esc(m.source||'')}" placeholder="例如：原文页面 / 作者截图"></div><div><label class="form-label">记录日期</label><input name="observed_at" type="date" value="${esc((m.observed_at||'').slice(0,10))}"></div></div><p class="help">未公开的数据请留空；搜索排序不能代表热度高低。</p></div>`;}
function readMetrics(fd){return {reads:fd.get('reads')||'',likes:fd.get('likes')||'',favorites:fd.get('favorites')||'',source:fd.get('metric_source')||'',observed_at:fd.get('observed_at')||''};}
function researchModal(){showModal('搜索产业文章',`<form id="research-form"><div class="field"><label class="form-label" for="research-query">想收集哪方面的资料？</label><input id="research-query" name="query" required placeholder="例如：ADB 智能车灯 供应链 量产" value=""></div><div class="field"><label class="form-label" for="scope">搜索范围</label><select name="scope" id="scope"><option value="wechat">公众号文章 · 微信公开页面</option><option value="web">全网行业资料</option></select></div><div class="inline-notice">搜索返回真实链接与可访问内容。部分网页只能获取摘要，会明确标注；没有公开的阅读、点赞、收藏不会自动补全。</div><p class="help">${state.settings.tavily_configured?'使用已配置的 Tavily 密钥。':'当前使用免密试用，额度有限；如达到限额，可在设置中填入 Tavily 密钥。'}</p><div class="modal-actions"><button class="button primary" type="submit">${icon('search')} 搜索并存入素材库</button></div></form>`,{type:'research'});}
function articleDetail(id){const a=state.articles.find(a=>String(a.id)===String(id));if(!a)return;const url=safeURL(a.url);showModal('素材详情',`<div class="article-card-top"><span class="tag">${a.content_kind==='snippet'?'搜索摘要 · 需补充正文':'完整正文'}</span>${a.analysis?'<span class="tag">已完成拆解</span>':''}</div><h2 class="detail-title">${esc(a.title)}</h2><div class="detail-meta"><span>作者：${esc(a.author||'未记录')}</span><span>收藏于 ${esc(fmtDate(a.created_at))}</span><span>阅读 ${metricLabel(a.metrics?.reads)}</span><span>点赞 ${metricLabel(a.metrics?.likes)}</span><span>收藏 ${metricLabel(a.metrics?.favorites)}</span></div><div class="help">热度来源：${esc(a.metrics?.source||'未记录')} · 记录日期：${esc(fmtDate(a.metrics?.observed_at))}</div>${url?`<a class="source-link" href="${esc(url)}" target="_blank" rel="noopener noreferrer">查看原文 · ${esc(url)}</a>`:''}<div class="detail-section"><div class="article-controls"><button class="button primary small" data-analyze="${esc(a.id)}"${a.content_kind==='snippet'?' disabled title="请先补充完整正文"':''}>${icon('spark')} ${a.analysis?'重新拆解文章':'拆解文章'}</button><button class="button secondary small" data-edit-article="${esc(a.id)}">编辑正文与热度</button><button class="text-button" data-archive-article="${esc(a.id)}" style="margin-left:auto;color:#a28d76">移出素材库</button></div>${a.content_kind==='snippet'?'<div class="inline-notice">当前只有搜索摘要，无法据此完整拆解标题、开头与结构。点击「编辑正文与热度」补充原文。</div>':''}</div><section class="detail-section"><div class="detail-section-head"><h3>文章拆解</h3><button class="text-button" data-page-modal="cards">查看写法卡片 ${icon('arrow')}</button></div>${a.analysis?`<div class="detail-content">${esc(a.analysis)}</div>`:'<div class="no-analysis">拆解将提炼标题逻辑、开头方式、文章结构与可复用方法。生成的写法卡片需要你审核后才会用于创作。</div>'}</section><section class="detail-section"><h3>收藏的正文</h3><div class="detail-content">${esc(a.content)}</div></section>`,{wide:true,type:'article',id:a.id});}
function editArticle(id){const a=state.articles.find(a=>String(a.id)===String(id));if(!a)return;showModal('编辑素材',`<form id="edit-article-form" data-id="${esc(id)}"><div class="field"><label class="form-label">文章标题</label><input name="title" value="${esc(a.title)}" required></div><div class="field"><label class="form-label">正文 <small>补充完整正文后可进行拆解</small></label><textarea name="content" rows="12" required>${esc(a.content)}</textarea></div><div class="form-row"><div><label class="form-label">原文链接</label><input name="url" type="url" value="${esc(a.url)}"></div><div><label class="form-label">作者 / 公众号</label><input name="author" value="${esc(a.author)}"></div></div>${metricsFields(a.metrics)}<div class="modal-actions"><button class="button primary" type="submit">${icon('check')} 保存素材</button></div></form>`,{type:'edit-article',id});}
function editCard(id){const c=state.cards.find(c=>String(c.id)===String(id));if(!c)return;showModal('编辑写法卡片',`<form id="edit-card-form" data-id="${esc(id)}"><div class="field"><label class="form-label">方法名称</label><input name="title" value="${esc(c.title)}" required></div><div class="field"><label class="form-label">分类</label><input name="category" value="${esc(c.category)}" required></div><div class="field"><label class="form-label">方法、使用条件与注意事项</label><textarea name="content" rows="10" required>${esc(c.content)}</textarea></div><label class="check-row"><input type="checkbox" name="approved"${c.approved?' checked':''}><span>我已审核，启用这张写法卡片</span></label><div class="modal-actions"><button class="button primary" type="submit">${icon('check')} 保存卡片</button></div></form>`,{type:'edit-card',id});}
function draftSources(d){
  const ctx=d.context||{}, refs=Array.isArray(d.references)?d.references:[];
  const sources=Array.isArray(ctx.articles)?ctx.articles:(ctx.article_ids||[]).map(id=>state.articles.find(a=>String(a.id)===String(id))).filter(Boolean);
  const merged=sources.length?sources:refs;
  const sourceRows=merged.map(r=>{if(typeof r==='string')return `<div>${esc(r)}</div>`;const url=safeURL(r.url);return `<div style="margin:6px 0">${url?`<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(r.title||'来源文章')}</a>`:esc(r.title||'来源文章')}${r.content_kind==='snippet'?' <span class="tag orange">搜索摘要</span>':''}</div>`;}).join('');
  const usage=Array.isArray(d.usage)?d.usage.map(x=>`<li>${esc(typeof x==='string'?x:JSON.stringify(x))}</li>`).join(''):'';
  return `<div class="inline-notice"><strong style="font-weight:500">写作依据：生成时最新笔记 · ${merged.length} 篇素材 · ${(ctx.card_ids||ctx.cards||[]).length} 张写法卡片</strong>${ctx.omitted_approved_cards?`<div>本次采用 12 张已审核卡片，其余 ${esc(ctx.omitted_approved_cards)} 张未纳入。</div>`:''}<details style="margin-top:8px"><summary style="cursor:pointer">查看来源与使用范围</summary>${sourceRows||'<div>本次没有选用文章素材。</div>'}${usage?`<ul style="padding-left:18px;margin:9px 0 0">${usage}</ul>`:''}${ctx.cards?.length?`<div style="margin-top:9px">参考写法：${ctx.cards.map(c=>esc(c.title)).join('、')}</div>`:''}</details></div>${d.editor_notes?`<details class="inline-notice"><summary style="cursor:pointer">发布前待核查事项</summary><div style="white-space:pre-wrap;margin-top:8px">${esc(typeof d.editor_notes==='string'?d.editor_notes:JSON.stringify(d.editor_notes))}</div></details>`:''}`;
}
function showDraft(id){const d=state.drafts.find(d=>String(d.id)===String(id));if(!d)return;activeDraft={...d};draftPreview=false;showModal('文章草稿',`<div class="field"><label class="form-label" for="draft-title">文章标题</label><input id="draft-title" value="${esc(d.title)}"></div><div class="notes-toolbar" style="padding:10px 0;background:transparent"><div class="preview-toggle"><button class="active" data-draft-mode="edit">编辑 Markdown</button><button data-draft-mode="preview">阅读视图</button></div><span class="help" id="draft-count">${chars(d.content).toLocaleString()} 字</span></div><div class="draft-editor"><label class="visually-hidden" for="draft-content">草稿正文</label><textarea id="draft-content" class="editor">${esc(d.content)}</textarea><div id="draft-preview" class="markdown-preview" hidden></div></div>${draftSources(d)}<div class="help">生成模型：${esc(d.model||'未记录')} · ${esc(fmtDate(d.created_at))}<br>请在发布前核对技术事实、引文与来源，补充你独有的行业判断。</div><div class="modal-actions"><button class="button secondary" data-action="copy-draft">复制正文</button><button class="button secondary" data-action="export-draft">${icon('file')} 导出 Markdown</button><button class="button primary" data-action="save-draft">${icon('check')} 保存修改</button></div>`,{wide:true,type:'draft',id});activeDraft={...d};}
async function saveDraft(button){if(!activeDraft)return false;const savedId=activeDraft.id;const title=$('#draft-title').value.trim(),content=$('#draft-content').value;return busy(button,async()=>{try{if(!title)throw new Error('请填写文章标题。');const result=await api(`/api/drafts/${encodeURIComponent(savedId)}`,{method:'PATCH',body:{title,content}});if(activeDraft&&String(activeDraft.id)===String(savedId)){activeDraft=result.draft||{...activeDraft,title,content};modalDirty=$('#draft-title').value.trim()!==title||$('#draft-content').value!==content;$('#draft-count').textContent=`${chars($('#draft-content').value).toLocaleString()} 字${modalDirty?' · 未保存':''}`;}await reloadState(true);toast(modalDirty?'已保存提交时的草稿，之后新增的编辑仍待保存。':'草稿已保存。');return !modalDirty;}catch(e){toast(e.message,true);return false;}});}

async function registerJob(data,action,info={}){if(!data.job_id)throw new Error('服务没有返回任务编号。');trackedJobs.set(String(data.job_id),{action,...info});updateJobsStrip();toast(({draft:'开始写作，可以继续整理素材。',research:'开始搜索，结果会自动存入素材库。',analyze:'开始拆解，写法卡片生成后等待你审核。',test:'正在测试模型连接…'})[action]||'任务已开始。');await pollJobs();}
function updateJobsStrip(){const strip=$('#job-strip');strip.hidden=!trackedJobs.size;if(trackedJobs.size){const tasks=[...trackedJobs.values()];const names={draft:'正在写作',research:'正在搜索产业文章',analyze:'正在拆解文章',test:'正在测试模型'};const modelTasks=tasks.some(t=>t.action!=='research');const hint=modelTasks?(state.settings.provider==='codex'?`${modelLabel()} 正在处理资料，使用同一账号 Codex 额度。`:state.settings.provider==='ollama'?'本地模型可能需要几分钟，你可以继续使用工作台。':'模型正在处理资料，你可以继续使用工作台。'):'正在检索并读取可访问网页，结果会自动保存。';strip.innerHTML=`<span class="spinner"></span><span>${esc(tasks.map(t=>names[t.action]||'后台任务处理中').join(' · '))}。${esc(hint)}</span>`;}}
async function pollJobs(){if(jobsBusy||!trackedJobs.size)return;jobsBusy=true;try{for(const [id,meta] of [...trackedJobs]){let job;try{job=await api(`/api/jobs/${encodeURIComponent(id)}`);}catch(e){if(e.status===404){trackedJobs.delete(id);toast('任务已失效，请重新发起。',true);}continue;}if(job.status==='running'||job.status==='pending'||job.status==='queued')continue;trackedJobs.delete(id);if(job.status==='error'){toast(job.error||job.message||'任务没有完成，请重试。',true);continue;}await reloadState(true);if(meta.action==='draft'){toast('文章草稿已生成。');if(!modal){const d=job.result?.draft||job.result;const draft=state.drafts.find(x=>String(x.id)===String(d?.id))||state.drafts[0];if(draft)showDraft(draft.id);}}else if(meta.action==='analyze'){toast('文章拆解完成。请审核新生成的写法卡片。');if(modal?.type==='article'&&String(modal.id)===String(meta.articleId)&&!modalDirty)articleDetail(meta.articleId);}else if(meta.action==='research'){toast('搜索完成，真实来源已存入素材库。');if(page==='home'&&!modal&&!composer.brief)await navigate('articles');}else if(meta.action==='test'){toast(typeof job.result==='string'?job.result:(job.result?.message||job.message||'模型连接正常。'));}}}finally{jobsBusy=false;updateJobsStrip();}}

document.addEventListener('click',async event=>{
  const b=event.target.closest('button,a');if(!b)return;
  if(b.matches('a.brand')){event.preventDefault();await navigate('home');return;}
  if(b.dataset.page){await navigate(b.dataset.page);return;}
  if(b.dataset.pageModal){if(closeModal())await navigate(b.dataset.pageModal);return;}
  if(b.dataset.topic){composer.brief=b.dataset.topic;$('#brief').value=composer.brief;$('#brief').focus();return;}
  if(b.dataset.addTab){addArticle(b.dataset.addTab);return;}
  if(b.dataset.article){articleDetail(b.dataset.article);return;}
  if(b.dataset.editArticle){editArticle(b.dataset.editArticle);return;}
  if(b.dataset.editCard){editCard(b.dataset.editCard);return;}
  if(b.dataset.draft){showDraft(b.dataset.draft);return;}
  if(b.dataset.draftMode){draftPreview=b.dataset.draftMode==='preview';$('#draft-content').hidden=draftPreview;$('#draft-preview').hidden=!draftPreview;$('#draft-preview').textContent=$('#draft-content').value;$$('[data-draft-mode]').forEach(x=>x.classList.toggle('active',x===b));return;}
  if(b.dataset.approveCard){await busy(b,async()=>{try{await api(`/api/cards/${encodeURIComponent(b.dataset.approveCard)}`,{method:'PATCH',body:{approved:b.dataset.approved==='true'}});await reloadState();toast(b.dataset.approved==='true'?'卡片已启用，将用于后续写作。':'卡片已停用。');}catch(e){toast(e.message,true);}});return;}
  if(b.dataset.analyze){await busy(b,async()=>{try{const result=await api(`/api/articles/${encodeURIComponent(b.dataset.analyze)}/analyze`,{method:'POST',body:{}});await registerJob(result,'analyze',{articleId:b.dataset.analyze});}catch(e){toast(e.message,true);}});return;}
  if(b.dataset.archiveArticle){if(!confirm('将这篇文章移出素材库？已生成的草稿会保留。'))return;await busy(b,async()=>{try{await api(`/api/articles/${encodeURIComponent(b.dataset.archiveArticle)}`,{method:'DELETE'});closeModal(true);await reloadState();toast('文章已移出素材库。');}catch(e){toast(e.message,true);}});return;}
  const action=b.dataset.action;
  if(action==='add-article')addArticle();
  else if(action==='research')researchModal();
  else if(action==='use-codex-gpt6'){$('#provider').value='codex';updateProviderFields(false);$('#model').value='gpt-6-astra';settingsDirty=true;$('#model').focus();}
  else if(action==='close-modal')closeModal();
  else if(action==='save-notes')await saveNotes(b);
  else if(action==='open-notes')await busy(b,async()=>{try{await api('/api/open-notes',{method:'POST',body:{}});toast('已请求本地编辑器打开当前 Markdown 文件。');}catch(e){toast(e.message,true);}});
  else if(action==='reload-notes'){if(noteSession.dirty&&!confirm('加载磁盘版本会放弃网页编辑区中未保存的修改，是否继续？'))return;noteSession={...noteConflict,dirty:false};state.notes=noteConflict;noteConflict=null;$('#notes-editor').value=noteSession.text;updateNoteIndicators();}
  else if(action==='merge-notes'){if(confirm('确认已在编辑区合并需要保留的内容？保存后将更新磁盘文件，旧版本会备份。'))await saveNotes(b,true);}
  else if(action==='save-draft')await saveDraft(b);
  else if(action==='copy-draft'){try{await navigator.clipboard.writeText(`# ${$('#draft-title').value.trim()}\n\n${$('#draft-content').value}`);toast('标题与正文已复制。');}catch{toast('浏览器无法直接复制，请在编辑区全选并复制。',true);}}
  else if(action==='export-draft'){const id=activeDraft?.id;if(!id)return;if(modalDirty&&!(await saveDraft(null)))return;const a=document.createElement('a');a.href=`/api/export/drafts/${encodeURIComponent(id)}`;a.download='';document.body.append(a);a.click();a.remove();}
  else if(action==='reload')location.reload();
  else if(action==='test-model'){if(settingsDirty){toast('请先保存设置，再测试你刚修改的模型。',true);return;}await busy(b,async()=>{try{await registerJob(await api('/api/test-model',{method:'POST',body:{}}),'test');}catch(e){toast(e.message,true);}});}
});

document.addEventListener('input',event=>{
  const e=event.target;
  if(e.closest('#compose-form'))syncComposer();
  if(e.id==='library-filter'){articleFilter.query=e.value;$('#article-results').innerHTML=articleResults();}
  if(e.id==='notes-editor'&&noteSession){noteSession.text=e.value;noteSession.dirty=e.value!==state.notes.text;updateNoteIndicators();}
  if(e.closest('#settings-form'))settingsDirty=true;
  if(e.closest('.modal')&&e.matches('input,textarea,select'))modalDirty=true;
  if(e.id==='draft-content')$('#draft-count').textContent=`${chars(e.value).toLocaleString()} 字 · 未保存`;
});
document.addEventListener('change',event=>{
  const e=event.target;
  if(e.closest('#compose-form'))syncComposer();
  if(e.id==='heat-filter'){articleFilter.heat=e.value;$('#article-results').innerHTML=articleResults();}
  if(e.id==='article-sort'){articleFilter.sort=e.value;$('#article-results').innerHTML=articleResults();}
  if(e.closest('#settings-form'))settingsDirty=true;
  if(e.closest('.modal')&&e.matches('input,textarea,select'))modalDirty=true;
  if(e.id==='provider')updateProviderFields(true);
});
function syncComposer(){const form=$('#compose-form');if(!form)return;const fd=new FormData(form);composer={brief:fd.get('brief'),audience:fd.get('audience'),tone:fd.get('tone'),length:fd.get('length'),article_ids:fd.getAll('article_ids').map(String),use_web:fd.has('use_web')};}

document.addEventListener('submit',async event=>{
  const form=event.target;if(!form.matches('form'))return;event.preventDefault();$('.form-error',form)?.remove();const button=$('button[type="submit"]',form),fd=new FormData(form);
  form.inert=true;
  await busy(button,async()=>{try{
    if(form.id==='compose-form'){syncComposer();if(!composer.brief.trim())throw new Error('请先写下文章主题。');const max=composer.use_web?5:8;if(composer.article_ids.length>max)throw new Error(`当前最多选择 ${max} 篇参考素材，请减少勾选后继续。`);const result=await api('/api/drafts',{method:'POST',body:{...composer,card_ids:[]}});await registerJob(result,'draft');}
    else if(form.id==='add-article-form'){const result=await api('/api/articles',{method:'POST',body:{title:fd.get('title'),content:fd.get('content'),url:fd.get('url'),author:fd.get('author'),metrics:readMetrics(fd)}});closeModal(true);await reloadState();toast('文章已收藏，可以开始拆解。');articleDetail(result.article.id);}
    else if(form.id==='import-form'){const result=await api('/api/import',{method:'POST',body:{url:fd.get('url')}});closeModal(true);await reloadState();toast('文章已成功导入。');articleDetail(result.article.id);}
    else if(form.id==='upload-form'){const file=fd.get('file');if(!file?.size)throw new Error('请选择需要上传的文件。');if(file.size>8*1024*1024)throw new Error('文件过大，请上传 8 MB 以内的文件。');const base64=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=()=>reject(new Error('文件读取失败。'));r.readAsDataURL(file);});const result=await api('/api/upload',{method:'POST',body:{filename:file.name,data:base64}});closeModal(true);await reloadState();toast('文件已导入素材库。');articleDetail(result.article.id);}
    else if(form.id==='research-form'){const result=await api('/api/research',{method:'POST',body:{query:fd.get('query'),scope:fd.get('scope'),max_results:5}});closeModal(true);if(page!=='articles')await navigate('articles');await registerJob(result,'research');}
    else if(form.id==='edit-article-form'){const id=form.dataset.id;await api(`/api/articles/${encodeURIComponent(id)}`,{method:'PATCH',body:{title:fd.get('title'),content:fd.get('content'),url:fd.get('url'),author:fd.get('author'),metrics:readMetrics(fd),content_kind:'full'}});closeModal(true);await reloadState();toast('素材已更新。');articleDetail(id);}
    else if(form.id==='edit-card-form'){await api(`/api/cards/${encodeURIComponent(form.dataset.id)}`,{method:'PATCH',body:{title:fd.get('title'),category:fd.get('category'),content:fd.get('content'),approved:fd.has('approved')}});closeModal(true);await reloadState();toast('写法卡片已保存。');}
    else if(form.id==='settings-form'){const payload=Object.fromEntries(fd.entries());if(payload.provider==='codex'){payload.base_url=$('#base_url').value||state.settings.base_url||'http://127.0.0.1:11434';delete payload.api_key;}await api('/api/settings',{method:'PUT',body:payload});settingsDirty=false;noteSession=null;noteConflict=null;await reloadState();toast('设置已保存。');}
  }catch(e){if(form.isConnected)formError(form,e.message);else toast(e.message,true);}finally{form.inert=false;}});
});

document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal)closeModal();if((e.metaKey||e.ctrlKey)&&e.key==='s'){if(page==='notes'&&!modal){e.preventDefault();saveNotes($('[data-action="save-notes"]'));}else if(modal?.type==='draft'){e.preventDefault();saveDraft($('[data-action="save-draft"]'));}}if(e.key==='Tab'&&modal){const focusable=$$('.modal button:not(:disabled),.modal input,.modal textarea,.modal select,.modal a[href],.modal summary').filter(x=>!x.hidden&&x.getClientRects().length);const first=focusable[0],last=focusable[focusable.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}});
window.addEventListener('beforeunload',e=>{if(hasUnsaved()||modalDirty||composer.brief.trim()){e.preventDefault();e.returnValue='';}});
window.addEventListener('hashchange',()=>navigate(location.hash.slice(1)));

async function init(){try{page=labels[location.hash.slice(1)]?location.hash.slice(1):'home';await reloadState();for(const job of state.jobs){if(['running','pending','queued'].includes(job.status)){const types={draft:'draft',drafts:'draft',generate:'draft',research:'research',analyze:'analyze',test_model:'test','test-model':'test',test:'test'};trackedJobs.set(String(job.id),{action:types[job.type]||job.type});}}updateJobsStrip();setInterval(pollJobs,2200);setInterval(pollNotes,5000);}catch(e){$('#main').innerHTML=emptyState('settings','暂时无法连接本地工作台',esc(e.message),'<button class="button secondary" data-action="reload">重新连接</button>');$('#model-status').textContent='本地服务未连接';$('#model-status').classList.add('status-error');}}
init();
