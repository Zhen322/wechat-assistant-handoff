# 字里 · 本地公众号写作工作台

Python 3.11+ stdlib ThreadingHTTPServer, SQLite, vanilla HTML/CSS/JS. Bind 127.0.0.1:8765 only. No Node build required. Actual persistent files under data/. No invented articles/metrics or fake AI results. Existing Ollama qwen2.5:latest at localhost:11434 works; default provider ollama, allow OpenAI-compatible API and Tavily configuration.

## Shared API contract
JSON requests/responses. Errors `{error: string}`, non-2xx. Dates ISO strings. No API keys ever returned; configured flags only. Local same-origin requests.

- GET /api/state -> `{articles:[],cards:[],drafts:[],notes:{text,path,revision},settings:{provider,base_url,model,search_provider,tavily_configured,api_key_configured,notes_path,profile},jobs:[],stats:{articles,cards,drafts}}`.
- GET /api/health -> `{ok:true}`.
- POST /api/articles -> `{article}`. Body `{title,content,url?,author?,tags?:[],metrics?:{reads:string,likes:string,favorites:string,source:string,observed_at:string}}`.
- PATCH /api/articles/ID -> `{article}`; same fields. DELETE -> archive, `{ok:true}`.
- POST /api/import -> `{article}`; body `{url}`; real fetch only, reject unavailable content with actionable message.
- POST /api/upload -> `{article}`; body `{filename,data}` base64; support .md .txt .html .docx (stdlib); PDF if pypdf available otherwise clear error.
- POST /api/articles/ID/analyze -> `{job_id}`; produces `article.analysis` markdown and reusable cards. Cards start approved=false.
- PATCH /api/cards/ID -> `{card}`; accepts approved boolean, title, content, category.
- POST /api/research -> `{job_id}`; body `{query,scope:'wechat'|'web',max_results:5}`; imports real search candidates; never infer metrics from search rank. Tavily officially supports capped keyless mode; try it when no API key configured, report genuine quota/network errors with configuration guidance. Public settings adds search_mode ('keyless'|'api_key'). Search candidates identify content_kind='snippet' unless full extraction succeeded.
- POST /api/drafts -> `{job_id}`; body `{brief,audience,tone,length,article_ids:[],card_ids:[],use_web:boolean}`. Read latest notes for every generation. Approved cards used by default when card_ids empty. Selection limited and reported, notes use full text up to explicit budget, must not silently truncate. Result `draft` saved as .md with references.
- PATCH /api/drafts/ID -> `{draft}`; body `{content,title?}`.
- GET /api/jobs/ID -> `{id,type,status:'running'|'done'|'error',message,result,error}`.
- GET /api/notes -> `{text,path,revision}` live-read disk; revision hash.
- PUT /api/notes -> `{text,path,revision}`; body `{text,revision}` optimistic concurrency 409 if external edit changed file. Atomic save and backup. Notes source is data/notes/我的思考.md unless configured absolute path. Existing user note must not be overwritten by selecting path.
- POST /api/open-notes -> `{ok:true}` opens current MD via macOS open (local app only).
- PUT /api/settings -> public settings; provider,base_url,model,api_key?,tavily_api_key?,notes_path?,profile?. Blank secrets preserve existing. notes_path must .md existing readable file; only user explicitly entering path selects external file. Settings stored mode 600.
- POST /api/test-model -> `{job_id}` sends tiny real model request.
- GET /api/export/drafts/ID -> downloadable Markdown.

## Data shapes
article = `{id,title,content,url,author,tags:[],metrics:{reads,likes,favorites,source,observed_at},source_type:'manual'|'upload'|'web',content_kind:'full'|'snippet',created_at,analysis?:string}`.
card = `{id,title,category,content,source_article_id,source_title,approved:boolean,created_at}`.
draft = `{id,title,content,references:[],created_at,model,file_path}`.
No sample data in real DB. Initial notebook may be a useful blank template, not invented user biography.

## engine.py contract (AI agent owns)
- fetch_article(url) -> `{title,content,url,author,content_kind:'full'}`; validate public http(s), no private/local URLs, redirects revalidated, max download 5 MB; decode Chinese, extract wechat js_content or article, fail on challenges/short text.
- search_articles(query,scope,max_results,settings) -> list of `{title,content,url,author,content_kind,source_type:'web',metrics:{},tags:[]}`; uses Tavily real API only, treat snippets explicitly; best-effort full extraction capped 3 articles to limit time.
- analyze_article(article,settings) -> `{analysis:string,cards:[{title,category,content}]}`; real LLM JSON parse validated, no invented metrics, mark snippet insufficient (refuse full analysis).
- generate_draft(request,articles,cards,notes,settings) -> `{title,content,references:[],model}`; notes is `{text,path,revision}`. Selected facts cite source IDs/URLs; considers profile, original personal notes, structure cards; must not turn source facts/experiences into author's own; use_web handled by app before call (real research merged into articles). Send topic keywords to search, not the full personal notebook.
- test_model(settings) -> string.
`settings` to engine includes private api_key and tavily_api_key. All untrusted source text clearly separated as data, not instructions. Timeouts explicit and errors useful. Do not log secrets.

## Ownership
backend agent: app.py (server/storage/routes/jobs), requirements.txt if needed.
engine agent: engine.py only.
frontend agent: static/index.html, static/app.js, static/styles.css only.
root: launch scripts, README, initial notes, tests, integration fixes after coordinating.
